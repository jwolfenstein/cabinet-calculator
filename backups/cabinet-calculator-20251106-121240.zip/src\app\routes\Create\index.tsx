import React, { useEffect, useMemo, useState } from 'react';
import TopNav from '../SOM/components/TopNav';
import { BuildStatusItems } from './components/BuildStatusItems';
import BuildModal from './components/BuildModal';
import type { BuildResult } from './components/BuildModal';
import { useUnits, inToMm, mmToIn, formatMm0_5 } from '../../store/units';
import UnitInput from '../../components/UnitInput';
import { toFraction } from '../../utils/fractions';

interface CabinetDesign {
  id: string;
  name: string;
  cabinetType: string;
  constructionMethod: 'raised-panel' | 'ship-lap' | 'flush-inset' | 'overlay' | 'inset-panel';
  width: number;
  height: number;
  depth: number;
  doorStyle: string;
  finish: string;
  createdDate: string;
  modifiedDate: string;
}

export default function CreateCabinets() {
  const { units, setUnits } = useUnits();
  const [cabinetStyle, setCabinetStyle] = useState<'frameless' | 'face-frame' | ''>('');
  const [selectedCabinetType, setSelectedCabinetType] = useState<'base' | 'upper' | 'wall' | ''>('');
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isBuildModalOpen, setIsBuildModalOpen] = useState<boolean>(false);
  const [isDefaultsModalOpen, setIsDefaultsModalOpen] = useState<boolean>(false);
  const [appearanceType, setAppearanceType] = useState<string>('');
  const [ffDims, setFfDims] = useState<{
    stileLeft: number;
    stileRight: number;
    railTop: number;
    railBottom: number;
    midStile: number;
    midRail: number;
    thickness: number;
    hasMidStile: boolean;
    hasMidRails: boolean;
  }>({
    stileLeft: 1.5,
    stileRight: 1.5,
    railTop: 1.5,
    railBottom: 1.5,
    midStile: 1.5,
    midRail: 1.5,
    thickness: 0.75,
    hasMidStile: false,
    hasMidRails: false,
  });

  // Load saved defaults when opening modal
  useEffect(() => {
    if (!isDefaultsModalOpen) return;
    try {
      const saved = localStorage.getItem('cc.defaults.faceFrame.v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        setFfDims((prev) => ({ ...prev, ...parsed }));
      }
      if (cabinetStyle && selectedCabinetType) {
        const key = `cc.defaults.appearance.${cabinetStyle}.${selectedCabinetType}`;
        const savedApp = localStorage.getItem(key);
        if (savedApp) setAppearanceType(savedApp);
      }
    } catch {}
  }, [isDefaultsModalOpen]);
  
  // Image catalog for appearance types by style + cabinet type
  const faceFrameImages: Record<string, { file: string; label: string }[]> = {
    base: [
      { file: '1-door-1-drawer.png', label: '1 Door / 1 Drawer' },
      { file: '2-door-1-drawer.png', label: '2 Door / 1 Drawer' },
      { file: '3-drawer.png', label: '3 Drawer Stack' }
    ],
    upper: [
      { file: 'upper-single-door.png', label: 'Upper Single Door' },
      { file: 'upper-double-doors.png', label: 'Upper Double Doors' }
    ],
    wall: [
      { file: 'wall-single-door.png', label: 'Wall Single Door' },
      { file: 'wall-double-door.png', label: 'Wall Double Doors' },
      { file: 'wall-split-single-door.png', label: 'Wall Split Single' },
      { file: 'wall-split-double-door.png', label: 'Wall Split Double' }
    ]
  };
  const framelessImages: Record<string, { file: string; label: string }[]> = {
    base: [
      { file: '1-drawer-1-door.png', label: '1 Drawer / 1 Door' },
      { file: '1-drawer-2-door.png', label: '1 Drawer / 2 Door' },
      { file: '3-drawer-stack.png', label: '3 Drawer Stack' },
      { file: 'base-blind-left.png', label: 'Base Blind Left' },
      { file: 'full-single-door.png', label: 'Full Single Door' },
      { file: 'full-2-door.png', label: 'Full Double Door' }
    ],
    upper: [
      { file: 'upper-single.png', label: 'Upper Single' },
      { file: 'upper-double.png', label: 'Upper Double' }
    ],
    wall: [
      { file: 'wall-single.png', label: 'Wall Single' },
      { file: 'wall-double.png', label: 'Wall Double' }
    ]
  };

  const appearanceOptions = useMemo(() => {
    if (!cabinetStyle || !selectedCabinetType) return [];
    const source = cabinetStyle === 'face-frame' ? faceFrameImages : framelessImages;
    const list = source[selectedCabinetType] || [];
    return list.slice().sort((a, b) => a.label.localeCompare(b.label));
  }, [cabinetStyle, selectedCabinetType]);
  const [buildResult, setBuildResult] = useState<BuildResult | null>(null);
  const [customSpecs, setCustomSpecs] = useState<{
    width?: number;
    height?: number;
    depth?: number;
    doorStyle?: string;
    finish?: string;
  }>({});




  // Convert fraction string to decimal
  const fromFraction = (fractionStr: string): number => {
    const trimmed = fractionStr.trim();
    if (!trimmed) return 0;
    
    // Handle whole numbers
    if (!trimmed.includes('/') && !trimmed.includes(' ')) {
      return parseFloat(trimmed) || 0;
    }
    
    let whole = 0;
    let fractionPart = trimmed;
    
    // Handle mixed numbers (e.g., "24 1/2")
    if (trimmed.includes(' ')) {
      const parts = trimmed.split(' ');
      whole = parseFloat(parts[0]) || 0;
      fractionPart = parts[1] || '';
    }
    
    // Handle fractions (e.g., "1/2")
    if (fractionPart.includes('/')) {
      const [numerator, denominator] = fractionPart.split('/');
      const fraction = (parseFloat(numerator) || 0) / (parseFloat(denominator) || 1);
      return whole + fraction;
    }
    
    return whole;
  };

  // Default specs by high-level cabinet type
  const defaultSpecsByType: Record<'base'|'upper'|'wall', { width: number; height: number; depth: number }> = {
    base:  { width: 24, height: 34.5, depth: 24 },
    upper: { width: 30, height: 30,   depth: 12 },
    wall:  { width: 30, height: 36,   depth: 12 },
  };

  // Get current cabinet specs (either default or custom)
  const getCurrentSpecs = () => {
    if (!selectedCabinetType) return null;
    const def = defaultSpecsByType[selectedCabinetType as 'base'|'upper'|'wall'];
    if (!def) return null;
    return {
      width: customSpecs.width ?? def.width,
      height: customSpecs.height ?? def.height,
      depth: customSpecs.depth ?? def.depth,
      doorStyle: customSpecs.doorStyle ?? 'Shaker',
      finish: customSpecs.finish ?? 'Natural'
    };
  };

  const specsDisplay = useMemo(() => {
    const s = getCurrentSpecs();
    if (!s) return null;
    if (units === 'in') return {
      widthText: `${toFraction(s.width)}"`,
      heightText: `${toFraction(s.height)}"`,
      depthText: `${toFraction(s.depth)}"`,
      unitLabel: 'in',
    } as const;
    // mm display: convert inches -> mm
    const w = inToMm(s.width);
    const h = inToMm(s.height);
    const d = inToMm(s.depth);
    return {
      widthText: `${formatMm0_5(w)} mm`,
      heightText: `${formatMm0_5(h)} mm`,
      depthText: `${formatMm0_5(d)} mm`,
      unitLabel: 'mm',
    } as const;
  }, [units, selectedCabinetType, customSpecs, cabinetStyle]);

  // Handle cabinet style change
  const handleCabinetStyleChange = (style: 'frameless' | 'face-frame' | '') => {
    setCabinetStyle(style);
    setSelectedCabinetType(''); // Reset cabinet type when style changes
    setCustomSpecs({});
    setIsEditModalOpen(false);
    setAppearanceType('');
  };

  // Handle cabinet type selection
  const handleCabinetTypeChange = (typeName: string) => {
    setSelectedCabinetType(typeName as 'base'|'upper'|'wall'|'');
    setCustomSpecs({}); // Reset custom specs when changing type
    setIsEditModalOpen(false);
    setAppearanceType('');
  };

  const handleSaveDefaults = () => {
    try {
      if (cabinetStyle === 'face-frame') {
        localStorage.setItem('cc.defaults.faceFrame.v1', JSON.stringify(ffDims));
      }
      if (cabinetStyle && selectedCabinetType && appearanceType) {
        const key = `cc.defaults.appearance.${cabinetStyle}.${selectedCabinetType}`;
        localStorage.setItem(key, appearanceType);
      }
    } catch {}
    setIsDefaultsModalOpen(false);
  };

  // Save cabinet to catalogue
  const handleSaveCabinet = () => {
    const specs = getCurrentSpecs();
    if (!specs) return;

    const newCabinet: CabinetDesign = {
      id: `cabinet-${Date.now()}`,
      name: selectedCabinetType,
      cabinetType: selectedCabinetType,
      constructionMethod: 'raised-panel', // Default construction method
      width: specs.width,
      height: specs.height,
      depth: specs.depth,
      doorStyle: specs.doorStyle,
      finish: specs.finish,
      createdDate: new Date().toISOString(),
      modifiedDate: new Date().toISOString()
    };

    // Save to localStorage catalogue
    try {
      const existingCabinets = JSON.parse(localStorage.getItem('cc.cabinet-catalogue.v1') || '[]');
      const updatedCabinets = [...existingCabinets, newCabinet];
      localStorage.setItem('cc.cabinet-catalogue.v1', JSON.stringify(updatedCabinets));
      
      alert(`Cabinet "${selectedCabinetType}" saved to catalogue!`);
      
      // Reset form
      setSelectedCabinetType('');
      setCabinetStyle('');
      setIsEditModalOpen(false);
      setCustomSpecs({});
    } catch (error) {
      console.error('Error saving cabinet:', error);
      alert('Error saving cabinet to catalogue');
    }
  };

  return (
    <div className="page">
      <div className="page-header page-header-create"></div>
      <TopNav active="Create" />
      
      <div className="create-cabinets-container">
        <div className="create-cabinets-header">
          <h1 className="section-title">Assembly Creator</h1>
          <p className="page-subtitle">Create Assemblies for Cabinet Catalogue.</p>
        </div>

        <div className="cabinet-selection-grid">
          {/* Left Panel - Selection Form */}
          <div className="selection-panel">
            <div className="selection-section">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <h3 className="selection-title" style={{ margin: 0 }}>Cabinet | Frames</h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <label htmlFor="units-select" style={{ fontSize: 12, color: 'var(--text-muted)' }}>Units</label>
                  <select id="units-select" className="input" style={{ width: 140 }} value={units} onChange={(e)=>setUnits(e.target.value as any)}>
                    <option value="in">Inches</option>
                    <option value="mm">Millimeters</option>
                  </select>
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Cabinet Style</label>
                  <select 
                    className="input cabinet-style-selector"
                    value={cabinetStyle}
                    onChange={(e) => handleCabinetStyleChange(e.target.value as 'frameless' | 'face-frame' | '')}
                  >
                    <option value="">Select Cabinet Style...</option>
                    <option value="frameless">Frameless</option>
                    <option value="face-frame">Face Frame</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Cabinet Type</label>
                  <select 
                    className="input cabinet-type-selector"
                    value={selectedCabinetType}
                    onChange={(e) => handleCabinetTypeChange(e.target.value)}
                    disabled={!cabinetStyle}
                  >
                    <option value="">
                      {cabinetStyle ? 'Select Cabinet Type...' : 'Select Cabinet Style First'}
                    </option>
                    {cabinetStyle && (
                      <>
                        <option value="base">Base</option>
                        <option value="upper">Upper</option>
                        <option value="wall">Wall</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              {/* Specifications Display (always visible) */}
              <div className="specs-section">
                <div className="specs-header" style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                  <h4 className="specs-title" style={{ margin: 0 }}>Specifications</h4>
                  <small style={{ color: 'var(--text-muted)', fontSize: 12 }}>Dimensions may be changed at job level.</small>
                </div>
                <div className="specs-grid compact-3">
                  {getCurrentSpecs() && specsDisplay ? (
                    (() => { const s = getCurrentSpecs()!; return (
                      <>
                        <div className="spec-item no-note">
                          <span className="spec-label">Width ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.width ?? s.width}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, width: v }))}
                          />
                        </div>
                        <div className="spec-item no-note">
                          <span className="spec-label">Height ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.height ?? s.height}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, height: v }))}
                          />
                        </div>
                        <div className="spec-item spec-item-depth">
                          <span className="spec-label">Depth ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.depth ?? s.depth}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, depth: v }))}
                          />
                          {cabinetStyle === 'face-frame' && (
                            <small className="spec-note">does not include door</small>
                          )}
                          {cabinetStyle === 'frameless' && (
                            <small className="spec-note">includes door</small>
                          )}
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Door Style:</span>
                          <select
                            className="input"
                            value={customSpecs.doorStyle ?? s.doorStyle}
                            onChange={(e) => setCustomSpecs(prev => ({ ...prev, doorStyle: e.target.value }))}
                          >
                            <option value="Shaker">Shaker</option>
                            <option value="Flat Panel">Flat Panel</option>
                            <option value="Raised Panel">Raised Panel</option>
                            <option value="Glass Insert">Glass Insert</option>
                          </select>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Finish:</span>
                          <select
                            className="input"
                            value={customSpecs.finish ?? s.finish}
                            onChange={(e) => setCustomSpecs(prev => ({ ...prev, finish: e.target.value }))}
                          >
                            <option value="Natural">Natural</option>
                            <option value="Stained">Stained</option>
                            <option value="Painted White">Painted White</option>
                            <option value="Painted Color">Painted Color</option>
                          </select>
                        </div>
                      </>
                    ); })()
                  ) : (
                    <>
                      <div className="spec-item">
                        <span className="spec-label">Width:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Height:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Depth:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Door Style:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Finish:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <small style={{ color: 'var(--text-muted)', marginTop: 6, display: 'block' }}>
                        Select a cabinet style and type to view specifications.
                      </small>
                    </>
                  )}
                </div>

                <div className="action-buttons">
                  <button
                    className="btn btn-success"
                    disabled={!selectedCabinetType || !cabinetStyle}
                    onClick={() => { setIsBuildModalOpen(true); }}
                    aria-disabled={!selectedCabinetType || !cabinetStyle}
                  >
                    Start Build Process
                  </button>
                  <button
                    className="btn btn-secondary"
                    disabled={!selectedCabinetType || !cabinetStyle}
                    onClick={() => setIsDefaultsModalOpen(true)}
                    aria-disabled={!selectedCabinetType || !cabinetStyle}
                  >
                    Set Door/Drawers
                  </button>
                  <button
                    className="btn btn-primary"
                    disabled={!selectedCabinetType || !cabinetStyle}
                    onClick={handleSaveCabinet}
                    aria-disabled={!selectedCabinetType || !cabinetStyle}
                  >
                    Save to Catalogue
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel - Build Status Summary */}
          <div className="drawing-panel compact">
            <h4 className="drawing-title">Build Status</h4>
            <div className="drawing-container">
              <div className="build-status-list">
                <BuildStatusItems
                  cabinetStyle={cabinetStyle}
                  selectedCabinetType={selectedCabinetType}
                  buildResult={buildResult}
                  getCurrentSpecs={getCurrentSpecs}
                  setBuildResult={setBuildResult}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modals */}
      <div className="modal-container">
        {/* Door/Drawers Defaults Modal (split screen) */}
        {isDefaultsModalOpen && (
          <div className="modal-backdrop" onClick={() => setIsDefaultsModalOpen(false)}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <h3 className="modal-title">Set Door/Drawers Defaults</h3>
              <p className="page-subtitle" style={{ marginTop: 0 }}>
                Configure default settings for drawers and doors used for this assembly.
              </p>
              <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start', marginBottom: 16, minHeight: 420 }}>
                {/* Left side controls */}
                <div style={{ flex: '1 1 55%' }}>
                  <div className="form-group" style={{ marginBottom: 16 }}>
                    <label style={{ fontSize: 12, color: 'var(--text-secondary)', fontWeight: 500 }}>Appearance Type</label>
                    <select
                      className="input"
                      disabled={!cabinetStyle || !selectedCabinetType}
                      value={appearanceType}
                      onChange={(e) => setAppearanceType(e.target.value)}
                    >
                      <option value="">{cabinetStyle && selectedCabinetType ? 'Select Appearance...' : 'Select Style & Type First'}</option>
                      {appearanceOptions.map(opt => (
                        <option key={opt.file} value={`${cabinetStyle}/${opt.file}`}>{opt.label}</option>
                      ))}
                    </select>
                    {!appearanceType && !!appearanceOptions.length && (
                      <small style={{ color: 'var(--text-muted)', marginTop: 6 }}>Choose a layout to preview it.</small>
                    )}
                    {!cabinetStyle && (
                      <small style={{ color: 'var(--text-muted)', marginTop: 6 }}>Select a cabinet style first.</small>
                    )}
                    {cabinetStyle && !selectedCabinetType && (
                      <small style={{ color: 'var(--text-muted)', marginTop: 6 }}>Select a cabinet type to see layouts.</small>
                    )}
                  </div>
                  {cabinetStyle === 'face-frame' && (
                    <div style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)', borderRadius: 8, padding: 12 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: 'var(--text-secondary)' }}>Face Frame Dimensions</div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                        <label style={{ gridColumn: '1 / 3', fontSize: 11, color: 'var(--text-muted)' }}>Stiles</label>
                        <div>
                          <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Left Stile</label>
                          <UnitInput
                            className="input"
                            units={units}
                            valueInInches={ffDims.stileLeft}
                            onChangeInches={(v) => setFfDims(prev => ({ ...prev, stileLeft: v ?? prev.stileLeft }))}
                          />
                        </div>
                        <div>
                          <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Right Stile</label>
                          <UnitInput
                            className="input"
                            units={units}
                            valueInInches={ffDims.stileRight}
                            onChangeInches={(v) => setFfDims(prev => ({ ...prev, stileRight: v ?? prev.stileRight }))}
                          />
                        </div>

                        <label style={{ gridColumn: '1 / 3', fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>Rails</label>
                        <div>
                          <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Top Rail</label>
                          <UnitInput
                            className="input"
                            units={units}
                            valueInInches={ffDims.railTop}
                            onChangeInches={(v) => setFfDims(prev => ({ ...prev, railTop: v ?? prev.railTop }))}
                          />
                        </div>
                        <div>
                          <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Bottom Rail</label>
                          <UnitInput
                            className="input"
                            units={units}
                            valueInInches={ffDims.railBottom}
                            onChangeInches={(v) => setFfDims(prev => ({ ...prev, railBottom: v ?? prev.railBottom }))}
                          />
                        </div>

                        <div style={{ gridColumn: '1 / 3', display: 'flex', gap: 12, alignItems: 'center', marginTop: 6 }}>
                          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
                            <input type="checkbox" checked={ffDims.hasMidStile} onChange={(e) => setFfDims(p=>({ ...p, hasMidStile: e.target.checked }))} /> Mid Stile
                          </label>
                          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
                            <input type="checkbox" checked={ffDims.hasMidRails} onChange={(e) => setFfDims(p=>({ ...p, hasMidRails: e.target.checked }))} /> Mid Rails
                          </label>
                        </div>

                        {ffDims.hasMidStile && (
                          <div style={{ gridColumn: '1 / 3' }}>
                            <label style={{ fontSize: 11, color: 'var(--text-muted)' }}>Mid Stile Width</label>
                            <UnitInput
                              className="input"
                              units={units}
                              valueInInches={ffDims.midStile}
                              onChangeInches={(v) => setFfDims(prev => ({ ...prev, midStile: v ?? prev.midStile }))}
                            />
                          </div>
                        )}

                        {ffDims.hasMidRails && (
                          <div style={{ gridColumn: '1 / 3' }}>
                            <label style={{ fontSize: 11, color: 'var(--text-muted)' }}>Mid Rail Width</label>
                            <UnitInput
                              className="input"
                              units={units}
                              valueInInches={ffDims.midRail}
                              onChangeInches={(v) => setFfDims(prev => ({ ...prev, midRail: v ?? prev.midRail }))}
                            />
                          </div>
                        )}

                        <div style={{ gridColumn: '1 / 3', display: 'grid', gridTemplateColumns: '1fr', gap: 8, marginTop: 6 }}>
                          <div>
                            <label style={{ fontSize: 11, color: 'var(--text-muted)' }}>Frame Thickness</label>
                            <UnitInput
                              className="input"
                              units={units}
                              valueInInches={ffDims.thickness}
                              onChangeInches={(v) => setFfDims(prev => ({ ...prev, thickness: v ?? prev.thickness }))}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                {/* Right side preview */}
                <div style={{ flex: '1 1 45%', textAlign: 'center' }}>
                  {appearanceType ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                      <img
                        src={`/images/cabinets/${appearanceType}`}
                        alt={appearanceType}
                        style={{ maxWidth: '220px', width: '100%', border: '1px solid var(--border-primary)', borderRadius: 8, background: 'var(--bg-tertiary)', padding: 12 }}
                      />
                      <small style={{ color: 'var(--text-muted)', fontSize: 11 }}>{appearanceType.split('/').slice(-1)[0].replace(/[-]/g, ' ').replace(/\.png$/,'')}</small>
                    </div>
                  ) : (
                    <div style={{ border: '1px dashed var(--border-primary)', borderRadius: 8, padding: 32, color: 'var(--text-muted)', fontSize: 12 }}>
                      No appearance selected.
                    </div>
                  )}
                </div>
              </div>

              <div className="modal-buttons">
                <button
                  className="btn btn-secondary"
                  onClick={() => setIsDefaultsModalOpen(false)}
                >
                  Close
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleSaveDefaults}
                >
                  Save Defaults
                </button>
              </div>
            </div>
          </div>
        )}
        {/* Edit Specifications Modal */}
        {isEditModalOpen && selectedCabinetType && (
          <div className="modal-backdrop" onClick={() => setIsEditModalOpen(false)}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <h3 className="modal-title">Edit Cabinet Specifications</h3>
              <div className="form-group">
                <label>Width ({units === 'in' ? 'inches' : 'mm'})</label>
                <UnitInput
                  className="input"
                  units={units}
                  valueInInches={customSpecs.width ?? getCurrentSpecs()?.width}
                  onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, width: v }))}
                />
                {units === 'in' ? (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {toFraction(customSpecs.width ?? getCurrentSpecs()?.width ?? 0)}"
                  </small>
                ) : (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {formatMm0_5(inToMm(customSpecs.width ?? getCurrentSpecs()?.width ?? 0))} mm
                  </small>
                )}
              </div>
              <div className="form-group">
                <label>Height ({units === 'in' ? 'inches' : 'mm'})</label>
                <UnitInput
                  className="input"
                  units={units}
                  valueInInches={customSpecs.height ?? getCurrentSpecs()?.height}
                  onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, height: v }))}
                />
                {units === 'in' ? (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {toFraction(customSpecs.height ?? getCurrentSpecs()?.height ?? 0)}"
                  </small>
                ) : (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {formatMm0_5(inToMm(customSpecs.height ?? getCurrentSpecs()?.height ?? 0))} mm
                  </small>
                )}
              </div>
              <div className="form-group">
                <label>Depth ({units === 'in' ? 'inches' : 'mm'})</label>
                <UnitInput
                  className="input"
                  units={units}
                  valueInInches={customSpecs.depth ?? getCurrentSpecs()?.depth}
                  onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, depth: v }))}
                />
                {units === 'in' ? (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {toFraction(customSpecs.depth ?? getCurrentSpecs()?.depth ?? 0)}"
                  </small>
                ) : (
                  <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                    = {formatMm0_5(inToMm(customSpecs.depth ?? getCurrentSpecs()?.depth ?? 0))} mm
                  </small>
                )}
              </div>
              <div className="form-group">
                <label>Door Style</label>
                <select 
                  className="input"
                  value={customSpecs.doorStyle ?? getCurrentSpecs()?.doorStyle ?? ''}
                  onChange={(e) => setCustomSpecs(prev => ({ ...prev, doorStyle: e.target.value }))}
                >
                  <option value="Shaker">Shaker</option>
                  <option value="Flat Panel">Flat Panel</option>
                  <option value="Raised Panel">Raised Panel</option>
                  <option value="Glass Insert">Glass Insert</option>
                </select>
              </div>
              <div className="form-group">
                <label>Finish</label>
                <select 
                  className="input"
                  value={customSpecs.finish ?? getCurrentSpecs()?.finish ?? ''}
                  onChange={(e) => setCustomSpecs(prev => ({ ...prev, finish: e.target.value }))}
                >
                  <option value="Natural">Natural</option>
                  <option value="Stained">Stained</option>
                  <option value="Painted White">Painted White</option>
                  <option value="Painted Color">Painted Color</option>
                </select>
              </div>
              <div className="modal-buttons">
                <button 
                  className="btn btn-secondary"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn btn-primary"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Apply Changes
                </button>
              </div>
            </div>
          </div>
        )}        {/* Build Process Modal */}
        {isBuildModalOpen && selectedCabinetType && cabinetStyle && (
          <BuildModal 
            selectedCabinet={{
              type: (selectedCabinetType === 'base' ? 'Base' : selectedCabinetType === 'upper' ? 'Upper' : 'Wall'),
              style: cabinetStyle as 'frameless' | 'face-frame',
              specs: getCurrentSpecs()!
            }}
            units={units}
            onComplete={(res) => { setBuildResult(res); try { console.log('Build complete:', res); } catch {} }}
            onClose={() => setIsBuildModalOpen(false)}
          />
        )}
      </div>
    </div>
  );
}
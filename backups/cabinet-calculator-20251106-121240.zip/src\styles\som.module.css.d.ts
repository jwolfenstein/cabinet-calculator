declare const classes: { [key: string]: string };
export default classes;

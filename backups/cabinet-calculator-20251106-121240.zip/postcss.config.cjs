// Minimal PostCSS config (no BOM)
module.exports = {
  plugins: {
    autoprefixer: {},
  },
};

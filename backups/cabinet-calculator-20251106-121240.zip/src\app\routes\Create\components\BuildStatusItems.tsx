import React from 'react';
import { BuildResult } from './BuildModal';
import { useUnits, inToMm, formatMm0_5 } from '../../../store/units';
import { toFraction } from '../../../utils/fractions';
import UnitInput from '../../../components/UnitInput';

interface BuildStatusItemsProps {
    cabinetStyle: string;
    selectedCabinetType: string;
    buildResult: BuildResult | null;
    getCurrentSpecs: () => { width: number; height: number; depth: number; doorStyle: string; finish: string; } | null;
    setBuildResult: React.Dispatch<React.SetStateAction<BuildResult | null>>;
}

interface ItemProps {
    label: string;
    value?: string;
    ok: boolean;
}

const Item = ({ label, value, ok }: ItemProps) => (
    <div className="build-status-item">
        <span className="label">{label}</span>
        <span className={ok ? 'status-ok' : 'status-bad'}>
            {value || (ok ? 'Complete' : 'Incomplete')}
        </span>
    </div>
);

export function BuildStatusItems({ cabinetStyle, selectedCabinetType, buildResult: br, getCurrentSpecs, setBuildResult }: BuildStatusItemsProps) {
    const { units } = useUnits();
    // Provide a lazy initializer so editing works even before the build modal runs
    const createInitialBuildResult = (): BuildResult => ({
        units,
        materials: {
            case: {
                ends: '', bottom: '', tops: '', stretchers: '', fixedShelf: '', adjShelf: '', backs: '', nailers: '', toeKick: '', toeSkirt: ''
            },
            hardware: { drawerGuides: '', hinges: '', hingePlates: '' }
        },
        backConstruction: undefined,
        // Defaults: dado depth 3/8" (.375), step rebate 1/4" (.25), blind offset 1/2" (.5)
        dados: { typeId: '', depthIn: 0.375, stepRebateIn: 0.25, blind: { enabled: false, frontsOnly: false, offsetIn: 0.5 } },
        // Defaults requested: attached yes, height 4", depth 2"
        toeKick: { attached: true, heightIn: 4, depthIn: 2, leftSetbackIn: 1, rightSetbackIn: 1 }
    });
    const hasStyle = !!cabinetStyle;
    const hasType = !!selectedCabinetType;
    const specs = getCurrentSpecs();
    const specsSet = !!(hasStyle && hasType && specs);

    const backSelected = !!br?.backConstruction?.id;
    const backDepthRequired = br?.backConstruction?.id === 'dado-thick-back' || br?.backConstruction?.id === 'inset-nailer-dado-back';
    const backDepthComplete = !backDepthRequired || (br?.backConstruction?.dadoDepthIn != null);

    const dadosSelected = !!br?.dados?.typeId;
    const dadosComplete = dadosSelected;
    const dadosDepthComplete = !br?.dados || br?.dados.typeId === 'no-dados' || (br?.dados.depthIn != null);
    const stepRebateComplete = br?.dados?.typeId !== 'step-dados' || (br?.dados?.stepRebateIn != null);

    const blindDecisionNeeded = !!br?.dados && br?.dados.typeId !== 'no-dados';
    const blindChoiceComplete = !blindDecisionNeeded || (br?.dados?.blind != null && typeof br?.dados?.blind?.enabled === 'boolean');
    const blindConfigComplete = !br?.dados?.blind?.enabled || (br?.dados?.blind?.offsetIn != null);

    const toe = br?.toeKick;
    const toeAttachComplete = toe ? toe.attached !== null : false;
    const toeDimsComplete = !!(toe && toe.heightIn != null && toe.depthIn != null);
    const toeSetbackComplete = !toe || toe.attached !== false || (toe.leftSetbackIn != null && toe.rightSetbackIn != null);

    // Small helpers
    const inputWidth = 120;
    const toeInputWidth = Math.max(40, Math.round(inputWidth / 3));
    const stepInches = units === 'in' ? 1 / 16 : (0.5 / 25.4);
    const clampNonNeg = (v?: number) => (v == null ? 0 : Math.max(0, v));

    const Stepper = ({ valueInches, onChange }: { valueInches?: number; onChange: (v: number) => void }) => (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <button type="button" className="btn btn-secondary" style={{ padding: '2px 6px' }}
                onClick={() => onChange(clampNonNeg((valueInches ?? 0) - stepInches))}>−</button>
            <button type="button" className="btn btn-secondary" style={{ padding: '2px 6px' }}
                onClick={() => onChange(clampNonNeg((valueInches ?? 0) + stepInches))}>+</button>
        </div>
    );

    // Back construction options (mirrors BuildModal)
    const backConstructionOptions = [
        { id: 'inset-thick-back', name: 'Inset Thick Back' },
        { id: 'inset-nailer-dado-back', name: 'Inset Nailer Dado Back' },
        { id: 'dado-thick-back', name: 'Dado Thick Back' },
        { id: 'inset-nailer-back', name: 'Inset Nailer Back' },
        { id: 'flush-nailer-back', name: 'Flush Nailer Back' },
    ] as const;

    // Helper for formatting measurements
    const formatMeasurement = (value: number | undefined, defaultValue = '—') => {
        if (value == null) return defaultValue;
        return units === 'in' ? `${toFraction(value)}"` : `${formatMm0_5(inToMm(value))} mm`;
    };

    return (
        <div>
            <Item label="Cabinet style" value={cabinetStyle || '—'} ok={hasStyle} />
            <Item label="Cabinet type" value={selectedCabinetType ? (selectedCabinetType === 'base' ? 'Base' : selectedCabinetType === 'upper' ? 'Upper' : 'Wall') : '—'} ok={hasType} />
            {specs && (
                <Item 
                    label="Dimensions" 
                    value={`${formatMeasurement(specs.width)}W × ${formatMeasurement(specs.height)}H × ${formatMeasurement(specs.depth)}D`}
                    ok={specsSet} 
                />
            )}
            {/* Back construction summary + editable dado depth when applicable */}
            <div className="build-status-item">
                <span className="label">Back construction</span>
                <span className={backSelected ? 'status-ok' : 'status-bad'}>
                    <select
                        className="input"
                        value={br?.backConstruction?.id ?? ''}
                        onChange={(e)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return {
                                ...base,
                                backConstruction: {
                                    id: e.target.value,
                                    name: backConstructionOptions.find(o=>o.id===e.target.value)?.name || e.target.value,
                                    ...(e.target.value === 'dado-thick-back' || e.target.value === 'inset-nailer-dado-back'
                                        ? { dadoDepthIn: base.backConstruction?.dadoDepthIn }
                                        : { dadoDepthIn: undefined }),
                                }
                            };
                        })}
                    >
                        <option value="">Select back...</option>
                        {backConstructionOptions.map(o=> (
                            <option key={o.id} value={o.id}>{o.name}</option>
                        ))}
                    </select>
                </span>
            </div>
            {br?.backConstruction && backDepthRequired && (
                <div className="build-status-item">
                    <span className="label">Back dado depth</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={br.backConstruction.dadoDepthIn}
                            style={{ width: inputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                if (!base.backConstruction) return base; // shouldn't happen if field visible
                                return { ...base, backConstruction: { ...base.backConstruction, dadoDepthIn: v } };
                            })}
                        />
                        <Stepper valueInches={br.backConstruction.dadoDepthIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            if (!base.backConstruction) return base;
                            return { ...base, backConstruction: { ...base.backConstruction, dadoDepthIn: v } };
                        })} />
                        <small style={{ color: 'var(--text-muted)' }}>
                            = {formatMeasurement(br.backConstruction.dadoDepthIn)}
                        </small>
                    </div>
                </div>
            )}

            {/* Dado type editable */}
            <div className="build-status-item">
                <span className="label">Dado type</span>
                <span className={dadosComplete ? 'status-ok' : 'status-bad'}>
                    <select
                        className="input"
                        value={br?.dados?.typeId ?? ''}
                        onChange={(e)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return {
                                ...base,
                                dados: {
                                    ...(base.dados ?? { typeId: '' as const }),
                                    typeId: e.target.value as any,
                                    depthIn: e.target.value === 'no-dados' ? undefined : base.dados?.depthIn,
                                    stepRebateIn: e.target.value === 'step-dados' ? base.dados?.stepRebateIn : undefined,
                                }
                            };
                        })}
                    >
                        <option value="">Select dado...</option>
                        <option value="no-dados">no dados</option>
                        <option value="full-thickness-dados">full thickness dados</option>
                        <option value="step-dados">step dados</option>
                    </select>
                </span>
            </div>
            {/* Dado depth editable when applicable */}
            {br?.dados && br.dados.typeId !== 'no-dados' && (
                <div className="build-status-item">
                    <span className="label">Dado depth</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={br.dados.depthIn}
                            style={{ width: inputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                return { ...base, dados: { ...(base.dados ?? { typeId: '' as const }), depthIn: v, typeId: base.dados?.typeId ?? '' as any } };
                            })}
                        />
                        <Stepper valueInches={br.dados.depthIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, dados: { ...(base.dados ?? { typeId: '' as const }), depthIn: v } };
                        })} />
                        <small style={{ color: 'var(--text-muted)' }}>
                            = {formatMeasurement(br.dados.depthIn)}
                        </small>
                    </div>
                </div>
            )}
            {/* Step rebate when step-dados */}
            {br?.dados && br.dados.typeId === 'step-dados' && (
                <div className="build-status-item">
                    <span className="label">Step rebate</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={br.dados.stepRebateIn}
                            style={{ width: inputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                return { ...base, dados: { ...(base.dados ?? { typeId: 'step-dados' }), stepRebateIn: v, typeId: 'step-dados' } };
                            })}
                        />
                        <Stepper valueInches={br.dados.stepRebateIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, dados: { ...(base.dados ?? { typeId: 'step-dados' }), stepRebateIn: v, typeId: 'step-dados' } };
                        })} />
                        <small style={{ color: 'var(--text-muted)' }}>
                            = {formatMeasurement(br.dados.stepRebateIn)}
                        </small>
                    </div>
                </div>
            )}

            {/* Blind dados editable */}
            {br?.dados && br.dados.typeId !== 'no-dados' && (
                <div className="build-status-item">
                    <span className="label">Blind dados</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
                        <label style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                            <input
                                type="checkbox"
                                checked={!!br.dados.blind?.enabled}
                                onChange={(e)=> setBuildResult(prev => {
                                    const base = prev ?? createInitialBuildResult();
                                    return {
                                        ...base,
                                        dados: { ...(base.dados ?? { typeId: '' as const }), blind: { ...(base.dados?.blind ?? { frontsOnly: false }), enabled: e.target.checked } }
                                    };
                                })}
                            />
                            Enabled
                        </label>
                        <label style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                            <input
                                type="checkbox"
                                disabled={!br.dados.blind?.enabled}
                                checked={!!br.dados.blind?.frontsOnly}
                                onChange={(e)=> setBuildResult(prev => {
                                    const base = prev ?? createInitialBuildResult();
                                    return {
                                        ...base,
                                        dados: { ...(base.dados ?? { typeId: '' as const }), blind: { ...(base.dados?.blind ?? { enabled: true }), frontsOnly: e.target.checked } }
                                    };
                                })}
                            />
                            Fronts only
                        </label>
                    </div>
                </div>
            )}
            {br?.dados?.blind?.enabled && (
                <div className="build-status-item">
                    <span className="label">Blind dado offset</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={br.dados.blind?.offsetIn}
                            style={{ width: inputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                return {
                                    ...base,
                                    dados: { ...(base.dados ?? { typeId: '' as const }), blind: { ...(base.dados?.blind ?? { enabled: true, frontsOnly: false }), offsetIn: v } }
                                };
                            })}
                        />
                        <Stepper valueInches={br.dados.blind?.offsetIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, dados: { ...(base.dados ?? { typeId: '' as const }), blind: { ...(base.dados?.blind ?? { enabled: true, frontsOnly: false }), offsetIn: v } } };
                        })} />
                        <small style={{ color: 'var(--text-muted)' }}>
                            = {formatMeasurement(br.dados.blind?.offsetIn)}
                        </small>
                    </div>
                </div>
            )}

            {/* Toe kick editable */}
            <div className="build-status-item">
                <span className="label">Toe kick attached</span>
                <span className={toeAttachComplete ? 'status-ok' : 'status-bad'}>
                    <select
                        className="input"
                        value={toe?.attached == null ? '' : toe.attached ? 'yes' : 'no'}
                        onChange={(e)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return {
                                ...base,
                                toeKick: { ...(base.toeKick ?? { attached: null }), attached: e.target.value === 'yes' ? true : e.target.value === 'no' ? false : null }
                            };
                        })}
                    >
                        <option value="">Select...</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </span>
            </div>
            <div className="build-status-item">
                <span className="label">Toe kick dimensions</span>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
                    <UnitInput
                        className="input input-narrow"
                        units={units}
                        valueInInches={toe?.heightIn}
                        style={{ width: toeInputWidth }}
                        onChangeInches={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, toeKick: { ...(base.toeKick ?? { attached: null }), heightIn: v } };
                        })}
                    />
                    <Stepper valueInches={toe?.heightIn} onChange={(v)=> setBuildResult(prev => {
                        const base = prev ?? createInitialBuildResult();
                        return { ...base, toeKick: { ...(base.toeKick ?? { attached: null }), heightIn: v } };
                    })} />
                    <span>H</span>
                    <UnitInput
                        className="input input-narrow"
                        units={units}
                        valueInInches={toe?.depthIn}
                        style={{ width: toeInputWidth }}
                        onChangeInches={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, toeKick: { ...(base.toeKick ?? { attached: null }), depthIn: v } };
                        })}
                    />
                    <Stepper valueInches={toe?.depthIn} onChange={(v)=> setBuildResult(prev => {
                        const base = prev ?? createInitialBuildResult();
                        return { ...base, toeKick: { ...(base.toeKick ?? { attached: null }), depthIn: v } };
                    })} />
                    <span>D</span>
                </div>
            </div>
            {toe?.attached === false && (
                <div className="build-status-item">
                    <span className="label">Toe kick setbacks</span>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={toe.leftSetbackIn}
                            style={{ width: toeInputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                return { ...base, toeKick: { ...(base.toeKick ?? { attached: false }), leftSetbackIn: v } };
                            })}
                        />
                        <Stepper valueInches={toe.leftSetbackIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, toeKick: { ...(base.toeKick ?? { attached: false }), leftSetbackIn: v } };
                        })} />
                        <span>L</span>
                        <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={toe.rightSetbackIn}
                            style={{ width: toeInputWidth }}
                            onChangeInches={(v)=> setBuildResult(prev => {
                                const base = prev ?? createInitialBuildResult();
                                return { ...base, toeKick: { ...(base.toeKick ?? { attached: false }), rightSetbackIn: v } };
                            })}
                        />
                        <Stepper valueInches={toe.rightSetbackIn} onChange={(v)=> setBuildResult(prev => {
                            const base = prev ?? createInitialBuildResult();
                            return { ...base, toeKick: { ...(base.toeKick ?? { attached: false }), rightSetbackIn: v } };
                        })} />
                        <span>R</span>
                    </div>
                </div>
            )}
        </div>
    );
}
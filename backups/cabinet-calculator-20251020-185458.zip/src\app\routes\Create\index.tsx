import React, { useMemo, useState } from 'react';
import TopNav from '../SOM/components/TopNav';
import BuildModal from './components/BuildModal';
import type { BuildResult } from './components/BuildModal';
import { useUnits, inToMm, mmToIn, formatMm0_5 } from '../../store/units';
import UnitInput from '../../components/UnitInput';

interface CabinetDesign {
  id: string;
  name: string;
  cabinetType: string;
  constructionMethod: 'raised-panel' | 'ship-lap' | 'flush-inset' | 'overlay' | 'inset-panel';
  width: number;
  height: number;
  depth: number;
  doorStyle: string;
  finish: string;
  createdDate: string;
  modifiedDate: string;
}

export default function CreateCabinets() {
  const { units, setUnits } = useUnits();
  const [cabinetStyle, setCabinetStyle] = useState<'frameless' | 'face-frame' | ''>('');
  const [selectedCabinetType, setSelectedCabinetType] = useState<'base' | 'upper' | 'wall' | ''>('');
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isBuildModalOpen, setIsBuildModalOpen] = useState<boolean>(false);
  const [buildResult, setBuildResult] = useState<BuildResult | null>(null);
  const [customSpecs, setCustomSpecs] = useState<{
    width?: number;
    height?: number;
    depth?: number;
    doorStyle?: string;
    finish?: string;
  }>({});


  // Convert decimal to fraction for display
  const toFraction = (decimal: number): string => {
    const whole = Math.floor(decimal);
    const remainder = decimal - whole;
    
    if (remainder === 0) {
      return whole.toString();
    }
    
    // Convert to sixteenths
    const sixteenths = Math.round(remainder * 16);
    
    if (sixteenths === 0) {
      return whole.toString();
    }
    
    if (sixteenths === 16) {
      return (whole + 1).toString();
    }
    
    // Simplify fraction
    const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
    const divisor = gcd(sixteenths, 16);
    const numerator = sixteenths / divisor;
    const denominator = 16 / divisor;
    
    const fractionPart = `${numerator}/${denominator}`;
    return whole > 0 ? `${whole} ${fractionPart}` : fractionPart;
  };

  // Convert fraction string to decimal
  const fromFraction = (fractionStr: string): number => {
    const trimmed = fractionStr.trim();
    if (!trimmed) return 0;
    
    // Handle whole numbers
    if (!trimmed.includes('/') && !trimmed.includes(' ')) {
      return parseFloat(trimmed) || 0;
    }
    
    let whole = 0;
    let fractionPart = trimmed;
    
    // Handle mixed numbers (e.g., "24 1/2")
    if (trimmed.includes(' ')) {
      const parts = trimmed.split(' ');
      whole = parseFloat(parts[0]) || 0;
      fractionPart = parts[1] || '';
    }
    
    // Handle fractions (e.g., "1/2")
    if (fractionPart.includes('/')) {
      const [numerator, denominator] = fractionPart.split('/');
      const fraction = (parseFloat(numerator) || 0) / (parseFloat(denominator) || 1);
      return whole + fraction;
    }
    
    return whole;
  };

  // Default specs by high-level cabinet type
  const defaultSpecsByType: Record<'base'|'upper'|'wall', { width: number; height: number; depth: number }> = {
    base:  { width: 24, height: 34.5, depth: 24 },
    upper: { width: 30, height: 30,   depth: 12 },
    wall:  { width: 30, height: 36,   depth: 12 },
  };

  // Get current cabinet specs (either default or custom)
  const getCurrentSpecs = () => {
    if (!selectedCabinetType) return null;
    const def = defaultSpecsByType[selectedCabinetType as 'base'|'upper'|'wall'];
    if (!def) return null;
    return {
      width: customSpecs.width ?? def.width,
      height: customSpecs.height ?? def.height,
      depth: customSpecs.depth ?? def.depth,
      doorStyle: customSpecs.doorStyle ?? 'Shaker',
      finish: customSpecs.finish ?? 'Natural'
    };
  };

  const specsDisplay = useMemo(() => {
    const s = getCurrentSpecs();
    if (!s) return null;
    if (units === 'in') return {
      widthText: `${toFraction(s.width)}"`,
      heightText: `${toFraction(s.height)}"`,
      depthText: `${toFraction(s.depth)}"`,
      unitLabel: 'in',
    } as const;
    // mm display: convert inches -> mm
    const w = inToMm(s.width);
    const h = inToMm(s.height);
    const d = inToMm(s.depth);
    return {
      widthText: `${formatMm0_5(w)} mm`,
      heightText: `${formatMm0_5(h)} mm`,
      depthText: `${formatMm0_5(d)} mm`,
      unitLabel: 'mm',
    } as const;
  }, [units, selectedCabinetType, customSpecs, cabinetStyle]);

  // Handle cabinet style change
  const handleCabinetStyleChange = (style: 'frameless' | 'face-frame' | '') => {
    setCabinetStyle(style);
    setSelectedCabinetType(''); // Reset cabinet type when style changes
    setCustomSpecs({});
    setIsEditModalOpen(false);
  };

  // Handle cabinet type selection
  const handleCabinetTypeChange = (typeName: string) => {
    setSelectedCabinetType(typeName as 'base'|'upper'|'wall'|'');
    setCustomSpecs({}); // Reset custom specs when changing type
    setIsEditModalOpen(false);
  };

  // Save cabinet to catalogue
  const handleSaveCabinet = () => {
    const specs = getCurrentSpecs();
    if (!specs) return;

    const newCabinet: CabinetDesign = {
      id: `cabinet-${Date.now()}`,
      name: selectedCabinetType,
      cabinetType: selectedCabinetType,
      constructionMethod: 'raised-panel', // Default construction method
      width: specs.width,
      height: specs.height,
      depth: specs.depth,
      doorStyle: specs.doorStyle,
      finish: specs.finish,
      createdDate: new Date().toISOString(),
      modifiedDate: new Date().toISOString()
    };

    // Save to localStorage catalogue
    try {
      const existingCabinets = JSON.parse(localStorage.getItem('cc.cabinet-catalogue.v1') || '[]');
      const updatedCabinets = [...existingCabinets, newCabinet];
      localStorage.setItem('cc.cabinet-catalogue.v1', JSON.stringify(updatedCabinets));
      
      alert(`Cabinet "${selectedCabinetType}" saved to catalogue!`);
      
      // Reset form
      setSelectedCabinetType('');
      setCabinetStyle('');
      setIsEditModalOpen(false);
      setCustomSpecs({});
    } catch (error) {
      console.error('Error saving cabinet:', error);
      alert('Error saving cabinet to catalogue');
    }
  };

  return (
    <>
      <div className="page-header page-header-create"></div>
      <TopNav active="Create" />
      
      <div className="create-cabinets-container">
        <div className="create-cabinets-header">
          <h1 className="section-title">Assembly Creator</h1>
          <p className="page-subtitle">Select a cabinet type to view reference drawing and specifications.</p>
          <p className="page-subtitle">Dimensions may be changed at job level.</p>
        </div>

        <div className="cabinet-selection-grid">
          {/* Left Panel - Selection Form */}
          <div className="selection-panel">
            <div className="selection-section">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <h3 className="selection-title" style={{ margin: 0 }}>Cabinet | Frames</h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <label htmlFor="units-select" style={{ fontSize: 12, color: 'var(--text-muted)' }}>Units</label>
                  <select id="units-select" className="input" style={{ width: 140 }} value={units} onChange={(e)=>setUnits(e.target.value as any)}>
                    <option value="in">Inches</option>
                    <option value="mm">Millimeters</option>
                  </select>
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Cabinet Style</label>
                  <select 
                    className="input cabinet-style-selector"
                    value={cabinetStyle}
                    onChange={(e) => handleCabinetStyleChange(e.target.value as 'frameless' | 'face-frame' | '')}
                  >
                    <option value="">Select Cabinet Style...</option>
                    <option value="frameless">Frameless</option>
                    <option value="face-frame">Face Frame</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Cabinet Type</label>
                  <select 
                    className="input cabinet-type-selector"
                    value={selectedCabinetType}
                    onChange={(e) => handleCabinetTypeChange(e.target.value)}
                    disabled={!cabinetStyle}
                  >
                    <option value="">
                      {cabinetStyle ? 'Select Cabinet Type...' : 'Select Cabinet Style First'}
                    </option>
                    {cabinetStyle && (
                      <>
                        <option value="base">Base</option>
                        <option value="upper">Upper</option>
                        <option value="wall">Wall</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              {/* Specifications Display (always visible) */}
              <div className="specs-section">
                <h4 className="specs-title">Specifications</h4>
                <div className="specs-grid compact-3">
                  {getCurrentSpecs() && specsDisplay ? (
                    (() => { const s = getCurrentSpecs()!; return (
                      <>
                        <div className="spec-item">
                          <span className="spec-label">Width ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.width ?? s.width}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, width: v }))}
                          />
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Height ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.height ?? s.height}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, height: v }))}
                          />
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Depth ({units === 'in' ? 'in' : 'mm'}):</span>
                          <UnitInput
                            className="input input-narrow"
                            units={units}
                            valueInInches={customSpecs.depth ?? s.depth}
                            onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, depth: v }))}
                          />
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Door Style:</span>
                          <select
                            className="input"
                            value={customSpecs.doorStyle ?? s.doorStyle}
                            onChange={(e) => setCustomSpecs(prev => ({ ...prev, doorStyle: e.target.value }))}
                          >
                            <option value="Shaker">Shaker</option>
                            <option value="Flat Panel">Flat Panel</option>
                            <option value="Raised Panel">Raised Panel</option>
                            <option value="Glass Insert">Glass Insert</option>
                          </select>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Finish:</span>
                          <select
                            className="input"
                            value={customSpecs.finish ?? s.finish}
                            onChange={(e) => setCustomSpecs(prev => ({ ...prev, finish: e.target.value }))}
                          >
                            <option value="Natural">Natural</option>
                            <option value="Stained">Stained</option>
                            <option value="Painted White">Painted White</option>
                            <option value="Painted Color">Painted Color</option>
                          </select>
                        </div>
                      </>
                    ); })()
                  ) : (
                    <>
                      <div className="spec-item">
                        <span className="spec-label">Width:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Height:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Depth:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Door Style:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <div className="spec-item">
                        <span className="spec-label">Finish:</span>
                        <span className="spec-value">—</span>
                      </div>
                      <small style={{ color: 'var(--text-muted)', marginTop: 6, display: 'block' }}>
                        Select a cabinet style and type to view specifications.
                      </small>
                    </>
                  )}
                </div>

                <div className="action-buttons">
                  <button
                    className="btn btn-success"
                    disabled={!selectedCabinetType || !cabinetStyle}
                    onClick={() => { setIsBuildModalOpen(true); }}
                    aria-disabled={!selectedCabinetType || !cabinetStyle}
                  >
                    Start Build Process
                  </button>
                  <button
                    className="btn btn-primary"
                    disabled={!selectedCabinetType || !cabinetStyle}
                    onClick={handleSaveCabinet}
                    aria-disabled={!selectedCabinetType || !cabinetStyle}
                  >
                    Save to Catalogue
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel - Build Status Summary */}
          <div className="drawing-panel compact">
            <h4 className="drawing-title">Build Status</h4>
            <div className="drawing-container">
              <div className="build-status-list">
                <div style={{ marginBottom: 8, color: 'var(--text-muted)' }}>
                  Reference pictures are disabled here. They will be used in Job → Construction.
                </div>

                {(() => {
                  const hasStyle = !!cabinetStyle;
                  const hasType = !!selectedCabinetType;
                  const specs = getCurrentSpecs();
                  const specsSet = !!(hasStyle && hasType && specs);

                  const br = buildResult;
                  const backSelected = !!br?.backConstruction?.id;
                  const backDepthRequired = br?.backConstruction?.id === 'dado-thick-back' || br?.backConstruction?.id === 'inset-nailer-dado-back';
                  const backDepthComplete = !backDepthRequired || (br?.backConstruction?.dadoDepthIn != null);

                  const dadosSelected = !!br?.dados?.typeId;
                  const dadosComplete = dadosSelected;
                  const dadosDepthComplete = !br?.dados || br?.dados.typeId === 'no-dados' || (br?.dados.depthIn != null);
                  const stepRebateComplete = br?.dados?.typeId !== 'step-dados' || (br?.dados?.stepRebateIn != null);

                  const blindDecisionNeeded = !!br?.dados && br?.dados.typeId !== 'no-dados';
                  const blindChoiceComplete = !blindDecisionNeeded || (br?.dados?.blind != null && typeof br?.dados?.blind?.enabled === 'boolean');
                  const blindConfigComplete = !br?.dados?.blind?.enabled || (br?.dados?.blind?.offsetIn != null);

                  const toe = br?.toeKick;
                  const toeAttachComplete = toe ? toe.attached !== null : false;
                  const toeDimsComplete = !!(toe && toe.heightIn != null && toe.depthIn != null);
                  const toeSetbackComplete = !toe || toe.attached !== false || (toe.leftSetbackIn != null && toe.rightSetbackIn != null);

                  const Item = ({label, ok}:{label:string; ok:boolean}) => (
                    <div className="build-status-item">
                      <span className="label">{label}</span>
                      <span className={ok ? 'status-ok' : 'status-bad'}>{ok ? 'Complete' : 'Incomplete'}</span>
                    </div>
                  );

                  return (
                    <div>
                      <Item label="Cabinet style selected" ok={hasStyle} />
                      <Item label="Cabinet type selected" ok={hasType} />
                      <Item label="Specifications set" ok={specsSet} />
                      <Item label="Back construction selected" ok={backSelected} />
                      <Item label="Back dado depth set" ok={backDepthComplete} />
                      <Item label="Dado option selected" ok={dadosComplete} />
                      <Item label="Dado depth set" ok={dadosDepthComplete} />
                      <Item label="Step rebate set (if step)" ok={stepRebateComplete} />
                      <Item label="Blind dado choice made" ok={blindChoiceComplete} />
                      <Item label="Blind dado offset set (if blind)" ok={blindConfigComplete} />
                      <Item label="Toe kick attached chosen" ok={toeAttachComplete} />
                      <Item label="Toe kick height/depth set" ok={toeDimsComplete} />
                      <Item label="Toe setbacks set (if not attached)" ok={toeSetbackComplete} />
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Specifications Modal */}
      {isEditModalOpen && selectedCabinetType && (
        <div className="modal-backdrop" onClick={() => setIsEditModalOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Edit Cabinet Specifications</h3>
            <div className="form-group">
              <label>Width ({units === 'in' ? 'inches' : 'mm'})</label>
              <UnitInput
                className="input"
                units={units}
                valueInInches={customSpecs.width ?? getCurrentSpecs()?.width}
                onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, width: v }))}
              />
              {units === 'in' ? (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {toFraction(customSpecs.width ?? getCurrentSpecs()?.width ?? 0)}"
                </small>
              ) : (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {formatMm0_5(inToMm(customSpecs.width ?? getCurrentSpecs()?.width ?? 0))} mm
                </small>
              )}
            </div>
            <div className="form-group">
              <label>Height ({units === 'in' ? 'inches' : 'mm'})</label>
              <UnitInput
                className="input"
                units={units}
                valueInInches={customSpecs.height ?? getCurrentSpecs()?.height}
                onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, height: v }))}
              />
              {units === 'in' ? (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {toFraction(customSpecs.height ?? getCurrentSpecs()?.height ?? 0)}"
                </small>
              ) : (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {formatMm0_5(inToMm(customSpecs.height ?? getCurrentSpecs()?.height ?? 0))} mm
                </small>
              )}
            </div>
            <div className="form-group">
              <label>Depth ({units === 'in' ? 'inches' : 'mm'})</label>
              <UnitInput
                className="input"
                units={units}
                valueInInches={customSpecs.depth ?? getCurrentSpecs()?.depth}
                onChangeInches={(v) => setCustomSpecs(prev => ({ ...prev, depth: v }))}
              />
              {units === 'in' ? (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {toFraction(customSpecs.depth ?? getCurrentSpecs()?.depth ?? 0)}"
                </small>
              ) : (
                <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                  = {formatMm0_5(inToMm(customSpecs.depth ?? getCurrentSpecs()?.depth ?? 0))} mm
                </small>
              )}
            </div>
            <div className="form-group">
              <label>Door Style</label>
              <select 
                className="input"
                value={customSpecs.doorStyle ?? getCurrentSpecs()?.doorStyle ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, doorStyle: e.target.value }))}
              >
                <option value="Shaker">Shaker</option>
                <option value="Flat Panel">Flat Panel</option>
                <option value="Raised Panel">Raised Panel</option>
                <option value="Glass Insert">Glass Insert</option>
              </select>
            </div>
            <div className="form-group">
              <label>Finish</label>
              <select 
                className="input"
                value={customSpecs.finish ?? getCurrentSpecs()?.finish ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, finish: e.target.value }))}
              >
                <option value="Natural">Natural</option>
                <option value="Stained">Stained</option>
                <option value="Painted White">Painted White</option>
                <option value="Painted Color">Painted Color</option>
              </select>
            </div>
            <div className="modal-buttons">
              <button 
                className="btn btn-secondary"
                onClick={() => setIsEditModalOpen(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-primary"
                onClick={() => setIsEditModalOpen(false)}
              >
                Apply Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Build Process Modal */}
      {isBuildModalOpen && selectedCabinetType && cabinetStyle && (
        <BuildModal 
          selectedCabinet={{
            type: (selectedCabinetType === 'base' ? 'Base' : selectedCabinetType === 'upper' ? 'Upper' : 'Wall'),
            style: cabinetStyle as 'frameless' | 'face-frame',
            specs: getCurrentSpecs()!
          }}
          units={units}
          onComplete={(res) => { setBuildResult(res); try { console.log('Build complete:', res); } catch {} }}
          onClose={() => setIsBuildModalOpen(false)}
        />
      )}
    </>
  );
}
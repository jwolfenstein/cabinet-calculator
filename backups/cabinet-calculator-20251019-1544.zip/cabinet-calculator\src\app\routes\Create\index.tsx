import React, { useState } from 'react';
import TopNav from '../SOM/components/TopNav';
import BuildModal from './components/BuildModal';

interface CabinetTypePreset {
  name: string;
  defaultWidth: number;
  defaultHeight: number;
  defaultDepth: number;
  category: 'base' | 'upper' | 'wall' | 'specialty';
}

interface CabinetDesign {
  id: string;
  name: string;
  cabinetType: string;
  constructionMethod: 'raised-panel' | 'ship-lap' | 'flush-inset' | 'overlay' | 'inset-panel';
  width: number;
  height: number;
  depth: number;
  doorStyle: string;
  finish: string;
  createdDate: string;
  modifiedDate: string;
}

export default function CreateCabinets() {
  const [cabinetStyle, setCabinetStyle] = useState<'frameless' | 'face-frame' | ''>('');
  const [selectedCabinetType, setSelectedCabinetType] = useState<string>('');
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isBuildModalOpen, setIsBuildModalOpen] = useState<boolean>(false);
  const [customSpecs, setCustomSpecs] = useState<{
    width?: number;
    height?: number;
    depth?: number;
    doorStyle?: string;
    finish?: string;
  }>({});

  // Convert decimal to fraction for display
  const toFraction = (decimal: number): string => {
    const whole = Math.floor(decimal);
    const remainder = decimal - whole;
    
    if (remainder === 0) {
      return whole.toString();
    }
    
    // Convert to sixteenths
    const sixteenths = Math.round(remainder * 16);
    
    if (sixteenths === 0) {
      return whole.toString();
    }
    
    if (sixteenths === 16) {
      return (whole + 1).toString();
    }
    
    // Simplify fraction
    const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
    const divisor = gcd(sixteenths, 16);
    const numerator = sixteenths / divisor;
    const denominator = 16 / divisor;
    
    const fractionPart = `${numerator}/${denominator}`;
    return whole > 0 ? `${whole} ${fractionPart}` : fractionPart;
  };

  // Convert fraction string to decimal
  const fromFraction = (fractionStr: string): number => {
    const trimmed = fractionStr.trim();
    if (!trimmed) return 0;
    
    // Handle whole numbers
    if (!trimmed.includes('/') && !trimmed.includes(' ')) {
      return parseFloat(trimmed) || 0;
    }
    
    let whole = 0;
    let fractionPart = trimmed;
    
    // Handle mixed numbers (e.g., "24 1/2")
    if (trimmed.includes(' ')) {
      const parts = trimmed.split(' ');
      whole = parseFloat(parts[0]) || 0;
      fractionPart = parts[1] || '';
    }
    
    // Handle fractions (e.g., "1/2")
    if (fractionPart.includes('/')) {
      const [numerator, denominator] = fractionPart.split('/');
      const fraction = (parseFloat(numerator) || 0) / (parseFloat(denominator) || 1);
      return whole + fraction;
    }
    
    return whole;
  };

  // Frameless cabinet types (without FF prefix)
  const framelessCabinets: CabinetTypePreset[] = [
    // Base Cabinets
    { name: '1 Drawer/1 Door', defaultWidth: 18, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: '1 Drawer/2 Door', defaultWidth: 24, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: 'Full Single Door', defaultWidth: 15, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: 'Full 2 Door', defaultWidth: 30, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: '3 Drawer Stack', defaultWidth: 18, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    
    // Upper Cabinets
    { name: 'Upper Single', defaultWidth: 15, defaultHeight: 30, defaultDepth: 12, category: 'upper' },
    { name: 'Upper Double', defaultWidth: 30, defaultHeight: 30, defaultDepth: 12, category: 'upper' },
    
    // Wall Cabinets
    { name: 'Wall Single', defaultWidth: 15, defaultHeight: 36, defaultDepth: 12, category: 'wall' },
    { name: 'Wall Double', defaultWidth: 30, defaultHeight: 36, defaultDepth: 12, category: 'wall' },
  ];

  // Face Frame cabinet types (FF prefix removed for display)
  const faceFrameCabinets: CabinetTypePreset[] = [
    // Base Cabinets
    { name: '3 Drawer', defaultWidth: 18, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: '1 Door 1 Drawer', defaultWidth: 18, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    { name: '2 Door 1 Drawer', defaultWidth: 24, defaultHeight: 34.5, defaultDepth: 24, category: 'base' },
    
    // Upper Cabinets
    { name: 'Upper Single Door', defaultWidth: 15, defaultHeight: 30, defaultDepth: 12, category: 'upper' },
    { name: 'Upper Double Doors', defaultWidth: 30, defaultHeight: 30, defaultDepth: 12, category: 'upper' },
    
    // Wall Cabinets
    { name: 'Wall Single Door', defaultWidth: 15, defaultHeight: 36, defaultDepth: 12, category: 'wall' },
    { name: 'Wall Double Door', defaultWidth: 30, defaultHeight: 36, defaultDepth: 12, category: 'wall' },
    { name: 'Wall Split Single Door', defaultWidth: 15, defaultHeight: 42, defaultDepth: 12, category: 'wall' },
    { name: 'Wall Split Double Door', defaultWidth: 30, defaultHeight: 42, defaultDepth: 12, category: 'wall' }
  ];

  // Get current cabinet list based on selected style
  const getCurrentCabinetList = () => {
    return cabinetStyle === 'face-frame' ? faceFrameCabinets : framelessCabinets;
  };

  // Image mapping for frameless cabinets (JPG)
  const getFramelessCabinetImage = (cabinetType: string): string | null => {
    const imageMap: { [key: string]: string } = {
      '1 Drawer/1 Door': '/images/cabinets/frameless/1-drawer-1-door.jpg',
      '1 Drawer/2 Door': '/images/cabinets/frameless/1-drawer-2-door.jpg', 
      'Full Single Door': '/images/cabinets/frameless/full-single-door.jpg',
      'Full 2 Door': '/images/cabinets/frameless/full-2-door.jpg',
      '3 Drawer Stack': '/images/cabinets/frameless/3-drawer-stack.jpg',
      'Upper Single': '/images/cabinets/frameless/upper-single.jpg',
      'Upper Double': '/images/cabinets/frameless/upper-double.jpg',
      'Wall Single': '/images/cabinets/frameless/wall-single.jpg',
      'Wall Double': '/images/cabinets/frameless/wall-double.jpg'
    };
    
    return imageMap[cabinetType] || null;
  };

  // Image mapping for face frame cabinets (PNG)
  const getFaceFrameCabinetImage = (cabinetType: string): string | null => {
    const imageMap: { [key: string]: string } = {
      '3 Drawer': '/images/cabinets/face-frame/3-drawer.png',
      '1 Door 1 Drawer': '/images/cabinets/face-frame/1-door-1-drawer.png',
      '2 Door 1 Drawer': '/images/cabinets/face-frame/2-door-1-drawer.png',
      'Upper Single Door': '/images/cabinets/face-frame/upper-single-door.png',
      'Upper Double Doors': '/images/cabinets/face-frame/upper-double-doors.png',
      'Wall Single Door': '/images/cabinets/face-frame/wall-single-door.png',
      'Wall Double Door': '/images/cabinets/face-frame/wall-double-door.png',
      'Wall Split Single Door': '/images/cabinets/face-frame/wall-split-single-door.png',
      'Wall Split Double Door': '/images/cabinets/face-frame/wall-split-double-door.png'
    };
    
    return imageMap[cabinetType] || null;
  };

  // Get cabinet image based on style and type
  const getCabinetImage = (): string | null => {
    if (cabinetStyle === 'frameless' && selectedCabinetType) {
      return getFramelessCabinetImage(selectedCabinetType);
    } else if (cabinetStyle === 'face-frame' && selectedCabinetType) {
      return getFaceFrameCabinetImage(selectedCabinetType);
    }
    return null;
  };

  // Get current cabinet specs (either default or custom)
  const getCurrentSpecs = () => {
    const currentList = getCurrentCabinetList();
    const preset = currentList.find(p => p.name === selectedCabinetType);
    if (!preset) return null;
    
    return {
      width: customSpecs.width ?? preset.defaultWidth,
      height: customSpecs.height ?? preset.defaultHeight,
      depth: customSpecs.depth ?? preset.defaultDepth,
      doorStyle: customSpecs.doorStyle ?? 'Shaker',
      finish: customSpecs.finish ?? 'Natural'
    };
  };

  // Handle cabinet style change
  const handleCabinetStyleChange = (style: 'frameless' | 'face-frame' | '') => {
    setCabinetStyle(style);
    setSelectedCabinetType(''); // Reset cabinet type when style changes
    setCustomSpecs({});
    setIsEditModalOpen(false);
  };

  // Handle cabinet type selection
  const handleCabinetTypeChange = (typeName: string) => {
    setSelectedCabinetType(typeName);
    setCustomSpecs({}); // Reset custom specs when changing type
    setIsEditModalOpen(false);
  };

  // Save cabinet to catalogue
  const handleSaveCabinet = () => {
    const specs = getCurrentSpecs();
    if (!specs) return;

    const newCabinet: CabinetDesign = {
      id: `cabinet-${Date.now()}`,
      name: selectedCabinetType,
      cabinetType: selectedCabinetType,
      constructionMethod: 'raised-panel', // Default construction method
      width: specs.width,
      height: specs.height,
      depth: specs.depth,
      doorStyle: specs.doorStyle,
      finish: specs.finish,
      createdDate: new Date().toISOString(),
      modifiedDate: new Date().toISOString()
    };

    // Save to localStorage catalogue
    try {
      const existingCabinets = JSON.parse(localStorage.getItem('cc.cabinet-catalogue.v1') || '[]');
      const updatedCabinets = [...existingCabinets, newCabinet];
      localStorage.setItem('cc.cabinet-catalogue.v1', JSON.stringify(updatedCabinets));
      
      alert(`Cabinet "${selectedCabinetType}" saved to catalogue!`);
      
      // Reset form
      setSelectedCabinetType('');
      setCabinetStyle('');
      setIsEditModalOpen(false);
      setCustomSpecs({});
    } catch (error) {
      console.error('Error saving cabinet:', error);
      alert('Error saving cabinet to catalogue');
    }
  };

  return (
    <>
      <div className="page-header page-header-create"></div>
      <TopNav active="Create" />
      
      <div className="create-cabinets-container">
        <div className="create-cabinets-header">
          <h1 className="section-title">Cabinet Addition</h1>
          <p className="page-subtitle">Select a cabinet type to view reference drawing and specifications.</p>
          <p className="page-subtitle">Dimensions may be changed at job level.</p>
        </div>

        <div className="cabinet-selection-grid">
          {/* Left Panel - Selection Form */}
          <div className="selection-panel">
            <div className="selection-section">
              <h3 className="selection-title">Cabinet | Frames</h3>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Cabinet Style</label>
                  <select 
                    className="input cabinet-style-selector"
                    value={cabinetStyle}
                    onChange={(e) => handleCabinetStyleChange(e.target.value as 'frameless' | 'face-frame' | '')}
                  >
                    <option value="">Select Cabinet Style...</option>
                    <option value="frameless">Frameless</option>
                    <option value="face-frame">Face Frame</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Cabinet Type</label>
                  <select 
                    className="input cabinet-type-selector"
                    value={selectedCabinetType}
                    onChange={(e) => handleCabinetTypeChange(e.target.value)}
                    disabled={!cabinetStyle}
                  >
                    <option value="">
                      {cabinetStyle ? 'Select Cabinet Type...' : 'Select Cabinet Style First'}
                    </option>
                    
                    {cabinetStyle && (
                      <>
                        <optgroup label="Base Cabinets">
                          {getCurrentCabinetList().filter(p => p.category === 'base').map(preset => (
                            <option key={preset.name} value={preset.name}>
                              {preset.name}
                            </option>
                          ))}
                        </optgroup>
                        
                        <optgroup label="Upper Cabinets">
                          {getCurrentCabinetList().filter(p => p.category === 'upper').map(preset => (
                            <option key={preset.name} value={preset.name}>
                              {preset.name}
                            </option>
                          ))}
                        </optgroup>
                        
                        <optgroup label="Wall Cabinets">
                          {getCurrentCabinetList().filter(p => p.category === 'wall').map(preset => (
                            <option key={preset.name} value={preset.name}>
                              {preset.name}
                            </option>
                          ))}
                        </optgroup>
                      </>
                    )}
                  </select>
                </div>
              </div>

              {/* Specifications Display */}
              {selectedCabinetType && (
                <div className="specs-section">
                  <h4 className="specs-title">Specifications</h4>
                  <div className="specs-grid">
                    {getCurrentSpecs() && (
                      <>
                        <div className="spec-item">
                          <span className="spec-label">Width:</span>
                          <span className="spec-value">{toFraction(getCurrentSpecs()!.width)}"</span>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Height:</span>
                          <span className="spec-value">{toFraction(getCurrentSpecs()!.height)}"</span>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Depth:</span>
                          <span className="spec-value">{toFraction(getCurrentSpecs()!.depth)}"</span>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Door Style:</span>
                          <span className="spec-value">{getCurrentSpecs()!.doorStyle}</span>
                        </div>
                        <div className="spec-item">
                          <span className="spec-label">Finish:</span>
                          <span className="spec-value">{getCurrentSpecs()!.finish}</span>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="action-buttons">
                    <button 
                      className="btn btn-secondary"
                      onClick={() => setIsEditModalOpen(true)}
                    >
                      Edit Specifications
                    </button>
                    <button 
                      className="btn btn-success"
                      onClick={() => {
                        setIsBuildModalOpen(true);
                      }}
                    >
                      Start Build Process
                    </button>
                    <button 
                      className="btn btn-primary"
                      onClick={handleSaveCabinet}
                    >
                      Save to Catalogue
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Reference Drawing */}
          <div className="drawing-panel">
            {selectedCabinetType ? (
              <div className="cabinet-drawing">
                <h4 className="drawing-title">Reference Drawing</h4>
                <div className="drawing-container">
                  <div className="drawing-content">
                    {getCabinetImage() ? (
                      <div className="cabinet-image-wrapper">
                        <div className="cabinet-image-container">
                          <img 
                            src={getCabinetImage()!} 
                            alt={`${selectedCabinetType} Cabinet`}
                            className="cabinet-image"
                          />
                        </div>
                        <div className="cabinet-info-panel">
                          <span className="cabinet-type-label">{selectedCabinetType}</span>
                          <div className={`cabinet-style-badge ${cabinetStyle}`}>
                            {cabinetStyle === 'frameless' ? 'Frameless' : 'Face Frame'}
                          </div>
                          {getCurrentSpecs() && (
                            <div className="drawing-dimensions">
                              <span>{toFraction(getCurrentSpecs()!.width)}"W × {toFraction(getCurrentSpecs()!.height)}"H × {toFraction(getCurrentSpecs()!.depth)}"D</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="drawing-placeholder">
                        <div className="cabinet-illustration">
                          <span className="cabinet-type-label">{selectedCabinetType}</span>
                          <div className={`cabinet-style-badge ${cabinetStyle}`}>
                            {cabinetStyle === 'frameless' ? 'Frameless' : 'Face Frame'}
                          </div>
                          <div className="drawing-specs">
                            {getCurrentSpecs() && (
                              <div className="drawing-dimensions">
                                <span>{toFraction(getCurrentSpecs()!.width)}"W × {toFraction(getCurrentSpecs()!.height)}"H × {toFraction(getCurrentSpecs()!.depth)}"D</span>
                              </div>
                            )}
                          </div>
                          <p className="image-coming-soon">Reference image coming soon</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="drawing-placeholder-empty">
                <p>Select a cabinet style and type to view reference drawing</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Specifications Modal */}
      {isEditModalOpen && selectedCabinetType && (
        <div className="modal-backdrop" onClick={() => setIsEditModalOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Edit Cabinet Specifications</h3>
            <div className="form-group">
              <label>Width (inches)</label>
              <input 
                type="number"
                className="input"
                step="0.0625"
                value={customSpecs.width ?? getCurrentSpecs()?.width ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, width: parseFloat(e.target.value) || undefined }))}
              />
              <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                = {toFraction(customSpecs.width ?? getCurrentSpecs()?.width ?? 0)}"
              </small>
            </div>
            <div className="form-group">
              <label>Height (inches)</label>
              <input 
                type="number"
                className="input"
                step="0.0625"
                value={customSpecs.height ?? getCurrentSpecs()?.height ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, height: parseFloat(e.target.value) || undefined }))}
              />
              <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                = {toFraction(customSpecs.height ?? getCurrentSpecs()?.height ?? 0)}"
              </small>
            </div>
            <div className="form-group">
              <label>Depth (inches)</label>
              <input 
                type="number"
                className="input"
                step="0.0625"
                value={customSpecs.depth ?? getCurrentSpecs()?.depth ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, depth: parseFloat(e.target.value) || undefined }))}
              />
              <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                = {toFraction(customSpecs.depth ?? getCurrentSpecs()?.depth ?? 0)}"
              </small>
            </div>
            <div className="form-group">
              <label>Door Style</label>
              <select 
                className="input"
                value={customSpecs.doorStyle ?? getCurrentSpecs()?.doorStyle ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, doorStyle: e.target.value }))}
              >
                <option value="Shaker">Shaker</option>
                <option value="Flat Panel">Flat Panel</option>
                <option value="Raised Panel">Raised Panel</option>
                <option value="Glass Insert">Glass Insert</option>
              </select>
            </div>
            <div className="form-group">
              <label>Finish</label>
              <select 
                className="input"
                value={customSpecs.finish ?? getCurrentSpecs()?.finish ?? ''}
                onChange={(e) => setCustomSpecs(prev => ({ ...prev, finish: e.target.value }))}
              >
                <option value="Natural">Natural</option>
                <option value="Stained">Stained</option>
                <option value="Painted White">Painted White</option>
                <option value="Painted Color">Painted Color</option>
              </select>
            </div>
            <div className="modal-buttons">
              <button 
                className="btn btn-secondary"
                onClick={() => setIsEditModalOpen(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-primary"
                onClick={() => setIsEditModalOpen(false)}
              >
                Apply Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Build Process Modal */}
      {isBuildModalOpen && selectedCabinetType && cabinetStyle && (
        <BuildModal 
          selectedCabinet={{
            type: selectedCabinetType,
            style: cabinetStyle as 'frameless' | 'face-frame',
            specs: getCurrentSpecs()!
          }}
          onClose={() => setIsBuildModalOpen(false)}
        />
      )}
    </>
  );
}
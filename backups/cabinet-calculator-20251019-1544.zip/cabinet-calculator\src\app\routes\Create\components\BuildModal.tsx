import React, { useState } from 'react';

type BackConstructionOption = {
  id: string;
  name: string;
  description: string;
  imagePath: string;
};

interface BuildModalProps {
  selectedCabinet: {
    type: string;
    style: 'frameless' | 'face-frame';
    specs: {
      width: number;
      height: number;
      depth: number;
      doorStyle: string;
      finish: string;
    };
  };
  onClose: () => void;
}

export default function BuildModal({ selectedCabinet, onClose }: BuildModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedBackConstruction, setSelectedBackConstruction] = useState<string>('');
  const [currentDiagramIndex, setCurrentDiagramIndex] = useState(0);
  const [dadoDepth, setDadoDepth] = useState<number>(0.25); // Default to 1/4"
  
  // Step 2: Dado construction options
  const [hasDados, setHasDados] = useState<boolean | null>(null);
  const [selectedDadoType, setSelectedDadoType] = useState<string>('');
  const [showBlindDadoPrompt, setShowBlindDadoPrompt] = useState<boolean>(false);
  const [useBlindDados, setUseBlindDados] = useState<boolean | null>(null);
  const [blindDadoFrontsOnly, setBlindDadoFrontsOnly] = useState<boolean>(true); // Default to fronts only
  const [dadoDepthStep2, setDadoDepthStep2] = useState<number>(0.375); // Default to 3/8"
  const [stepDadoRebate, setStepDadoRebate] = useState<number>(0.125); // Default to 1/8" rebate for step dados
  const [blindDadoOffset, setBlindDadoOffset] = useState<number>(0.125); // Default to 1/8"
  const [currentDadoDiagramIndex, setCurrentDadoDiagramIndex] = useState(0);

  // Convert decimal to fraction for display
  const toFraction = (decimal: number): string => {
    const whole = Math.floor(decimal);
    const remainder = decimal - whole;
    
    if (remainder === 0) {
      return whole.toString();
    }
    
    // Convert to sixteenths
    const sixteenths = Math.round(remainder * 16);
    
    if (sixteenths === 0) {
      return whole.toString();
    }
    
    if (sixteenths === 16) {
      return (whole + 1).toString();
    }
    
    // Simplify fraction
    const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
    const divisor = gcd(sixteenths, 16);
    const numerator = sixteenths / divisor;
    const denominator = 16 / divisor;
    
    const fractionPart = `${numerator}/${denominator}`;
    return whole > 0 ? `${whole} ${fractionPart}` : fractionPart;
  };

  // Back construction options with diagrams
  const backConstructionOptions: BackConstructionOption[] = [
    {
      id: 'inset-thick-back',
      name: 'Inset Thick Back',
      description: 'Thick back panel inset within the cabinet sides',
      imagePath: '/images/construction/inset-thick-back.JPG?v=2'
    },
    {
      id: 'inset-nailer-dado-back',
      name: 'Inset Nailer Dado Back',
      description: 'Nailer strip with dado joint, back panel inset',
      imagePath: '/images/construction/inset-nailer-dado-back.JPG?v=2'
    },
    {
      id: 'dado-thick-back',
      name: 'Dado Thick Back',
      description: 'Thick back panel set in dado grooves',
      imagePath: '/images/construction/dado-thick-back.JPG?v=2'
    },
    {
      id: 'inset-nailer-back',
      name: 'Inset Nailer Back',
      description: 'Nailer strip with inset back panel',
      imagePath: '/images/construction/inset-nailer-back.JPG?v=2'
    },
    {
      id: 'flush-nailer-back',
      name: 'Flush Nailer Back',
      description: 'Nailer strip with flush mounted back panel',
      imagePath: '/images/construction/flush-nailer-back.JPG?v=2'
    }
  ];

  // Dado construction options with diagrams
  const dadoConstructionOptions: BackConstructionOption[] = [
    {
      id: 'no-dados',
      name: 'No Dados',
      description: 'Traditional construction without dado joints - proceed to toe kicks',
      imagePath: '/images/construction/no-dado.png?v=2'
    },
    {
      id: 'full-thickness-dados',
      name: 'Full Thickness Dados',
      description: 'Dado width matches the thickness of the inserted part',
      imagePath: '/images/construction/full-thickness-dado.png?v=2'
    },
    {
      id: 'step-dados',
      name: 'Step Dados',
      description: 'Dados that stop at a specific depth with notch',
      imagePath: '/images/construction/step-dado.png?v=2'
    }
  ];

  // Blind dado option (separate)
  const blindDadoOption: BackConstructionOption = {
    id: 'blind-dados',
    name: 'Blind Dados',
    description: 'Applied to full or step dados - stops before front edge',
    imagePath: '/images/construction/blind-dado.png?v=2'
  };

  const handleNextDiagram = () => {
    setCurrentDiagramIndex((prev) => (prev + 1) % backConstructionOptions.length);
  };

  const handlePrevDiagram = () => {
    setCurrentDiagramIndex((prev) => (prev - 1 + backConstructionOptions.length) % backConstructionOptions.length);
  };

  const handleSelectConstruction = () => {
    setSelectedBackConstruction(backConstructionOptions[currentDiagramIndex].id);
    setCurrentStep(2);
  };

  // Dado construction handlers
  const handleNextDadoDiagram = () => {
    setCurrentDadoDiagramIndex((prev) => (prev + 1) % dadoConstructionOptions.length);
  };

  const handlePrevDadoDiagram = () => {
    setCurrentDadoDiagramIndex((prev) => (prev - 1 + dadoConstructionOptions.length) % dadoConstructionOptions.length);
  };

  const handleSelectDados = () => {
    const selectedOption = dadoConstructionOptions[currentDadoDiagramIndex];
    setSelectedDadoType(selectedOption.id);
    setHasDados(selectedOption.id !== 'no-dados');
    
    // If "No Dados" is selected, skip to toe kicks (step 5)
    if (selectedOption.id === 'no-dados') {
      setCurrentStep(5); // Skip to toe kicks
    } else if (selectedOption.id === 'full-thickness-dados' || selectedOption.id === 'step-dados') {
      // Show blind dado prompt for full thickness or step dados
      setShowBlindDadoPrompt(true);
      setCurrentStep(3); // Go to blind dado prompt
    }
  };

  const handleBlindDadoSelection = (useBlind: boolean) => {
    setUseBlindDados(useBlind);
    if (useBlind) {
      setCurrentStep(4); // Go to blind dado configuration
    } else {
      setCurrentStep(5); // Skip to toe kicks
    }
  };

  const handleBlindDadoConfig = () => {
    setCurrentStep(5); // Continue to toe kicks
  };

  const currentOption = backConstructionOptions[currentDiagramIndex];
  const currentDadoOption = dadoConstructionOptions[currentDadoDiagramIndex];

  // Check if current option requires dado depth input
  const requiresDadoDepth = currentOption.id === 'dado-thick-back' || currentOption.id === 'inset-nailer-dado-back';

  // Check if current dado option requires parameters
  const requiresDadoParams = currentDadoOption.id !== 'no-dados';
  const isBlindDado = useBlindDados === true;
  const isStepDado = selectedDadoType === 'step-dados';
  
  // Determine if step dados are relevant (only if full or step dados haven't been selected)
  const showStepDados = currentDadoDiagramIndex === 0 || currentDadoDiagramIndex === 2;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="build-modal" onClick={(e) => e.stopPropagation()}>
        <div className="build-modal-header">
          <h2>Cabinet Build Process</h2>
          <button className="modal-close-btn" onClick={onClose}>×</button>
        </div>
        
        <div className="build-modal-content">
          <p className="build-step-title">
            Step {currentStep}: {
              currentStep === 1 ? 'Back Construction Method' : 
              currentStep === 2 ? 'Dado Construction' :
              currentStep === 3 ? 'Blind Dado Option' :
              currentStep === 4 ? 'Blind Dado Configuration' :
              'Toe Kicks'
            }
          </p>
          
          <div className="selected-cabinet-summary">
            <strong>Building: {selectedCabinet.type} ({selectedCabinet.style})</strong>
            <span>Dimensions: {toFraction(selectedCabinet.specs.width)}"W × {toFraction(selectedCabinet.specs.height)}"H × {toFraction(selectedCabinet.specs.depth)}"D</span>
            {selectedBackConstruction && (
              <span>Back Construction: {backConstructionOptions.find(opt => opt.id === selectedBackConstruction)?.name}</span>
            )}
            {selectedDadoType && (
              <span>Dado Type: {dadoConstructionOptions.find(opt => opt.id === selectedDadoType)?.name}</span>
            )}
          </div>

          {/* Step 1: Back Construction */}
          {currentStep === 1 && (
            <div className="build-construction-selection">
              <div className="build-diagram-viewer">
                <div className="build-diagram-container">
                  <img 
                    src={currentOption.imagePath} 
                    alt={currentOption.name}
                    className="build-construction-diagram"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const placeholder = e.currentTarget.nextElementSibling as HTMLElement;
                      if (placeholder) placeholder.style.display = 'block';
                    }}
                  />
                  <div className="build-diagram-placeholder" style={{ display: 'none' }}>
                    <p>Diagram coming soon</p>
                    <p>{currentOption.name}</p>
                  </div>
                </div>
                
                <div className="build-diagram-controls">
                  <button className="btn btn-secondary" onClick={handlePrevDiagram}>
                    ← Previous
                  </button>
                  <span className="build-diagram-counter">
                    {currentDiagramIndex + 1} of {backConstructionOptions.length}
                  </span>
                  <button className="btn btn-secondary" onClick={handleNextDiagram}>
                    Next →
                  </button>
                </div>
              </div>

              <div className="build-construction-info">
                <h3>{currentOption.name}</h3>
                <p>{currentOption.description}</p>
                
                {requiresDadoDepth && (
                  <div className="dado-depth-input">
                    <label>Dado Depth (inches)</label>
                    <input 
                      type="number"
                      className="input"
                      step="0.0625"
                      value={dadoDepth}
                      onChange={(e) => setDadoDepth(parseFloat(e.target.value) || 0.25)}
                      min="0.125"
                      max="0.75"
                    />
                    <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                      = {toFraction(dadoDepth)}"
                    </small>
                  </div>
                )}
                
                <button 
                  className="btn btn-success"
                  onClick={handleSelectConstruction}
                >
                  Select This Construction Method
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Dado Construction */}
          {currentStep === 2 && (
            <div className="build-construction-selection">
              <div className="build-diagram-viewer">
                <div className="build-diagram-container">
                  <img 
                    src={currentDadoOption.imagePath} 
                    alt={currentDadoOption.name}
                    className="build-construction-diagram"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const placeholder = e.currentTarget.nextElementSibling as HTMLElement;
                      if (placeholder) placeholder.style.display = 'block';
                    }}
                  />
                  <div className="build-diagram-placeholder" style={{ display: 'none' }}>
                    <p>Diagram coming soon</p>
                    <p>{currentDadoOption.name}</p>
                  </div>
                </div>
                
                <div className="build-diagram-controls">
                  <button className="btn btn-secondary" onClick={handlePrevDadoDiagram}>
                    ← Previous
                  </button>
                  <span className="build-diagram-counter">
                    {currentDadoDiagramIndex + 1} of {dadoConstructionOptions.length}
                  </span>
                  <button className="btn btn-secondary" onClick={handleNextDadoDiagram}>
                    Next →
                  </button>
                </div>
              </div>

              <div className="build-construction-info">
                <h3>{currentDadoOption.name}</h3>
                <p>{currentDadoOption.description}</p>
                
                {requiresDadoParams && (
                  <div className="dado-parameters">
                    <div className="dado-depth-input">
                      <label>Dado Depth (inches)</label>
                      <input 
                        type="number"
                        className="input"
                        step="0.0625"
                        value={dadoDepthStep2}
                        onChange={(e) => setDadoDepthStep2(parseFloat(e.target.value) || 0.375)}
                        min="0.125"
                        max="1.0"
                      />
                      <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                        = {toFraction(dadoDepthStep2)}"
                      </small>
                    </div>

                    {isStepDado && (
                      <div className="dado-depth-input">
                        <label>Step Dado Rebate (inches)</label>
                        <input 
                          type="number"
                          className="input"
                          step="0.0625"
                          value={stepDadoRebate}
                          onChange={(e) => setStepDadoRebate(parseFloat(e.target.value) || 0.125)}
                          min="0.0625"
                          max="1.0"
                        />
                        <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                          = {toFraction(stepDadoRebate)}"
                        </small>
                      </div>
                    )}

                    {isBlindDado && (
                      <div className="dado-depth-input">
                        <label>Blind Dado Offset (inches)</label>
                        <input 
                          type="number"
                          className="input"
                          step="0.0625"
                          value={blindDadoOffset}
                          onChange={(e) => setBlindDadoOffset(parseFloat(e.target.value) || 0.125)}
                          min="0.0625"
                          max="2.0"
                        />
                        <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                          = {toFraction(blindDadoOffset)}"
                        </small>
                      </div>
                    )}
                  </div>
                )}
                
                <button 
                  className="btn btn-success"
                  onClick={handleSelectDados}
                >
                  Select Dado Construction
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Blind Dado Prompt */}
          {currentStep === 3 && (
            <div className="build-construction-selection">
              <div className="build-diagram-viewer">
                <div className="build-diagram-container">
                  <img 
                    src={blindDadoOption.imagePath} 
                    alt={blindDadoOption.name}
                    className="build-construction-diagram"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const placeholder = e.currentTarget.nextElementSibling as HTMLElement;
                      if (placeholder) placeholder.style.display = 'block';
                    }}
                  />
                  <div className="build-diagram-placeholder" style={{ display: 'none' }}>
                    <p>Diagram coming soon</p>
                    <p>{blindDadoOption.name}</p>
                  </div>
                </div>
              </div>

              <div className="build-construction-info">
                <h3>Blind Dado Option</h3>
                <p>Do you want to use blind dados for your {selectedDadoType === 'full-thickness-dados' ? 'full thickness' : 'step'} dados?</p>
                <p><em>Blind dados stop before the front edge, hiding the joint from the front view.</em></p>
                
                <div className="blind-dado-choices">
                  <button 
                    className="btn btn-success"
                    onClick={() => handleBlindDadoSelection(true)}
                  >
                    Yes - Use Blind Dados
                  </button>
                  <button 
                    className="btn btn-secondary"
                    onClick={() => handleBlindDadoSelection(false)}
                  >
                    No - Use Standard Dados
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Blind Dado Configuration */}
          {currentStep === 4 && useBlindDados && (
            <div className="build-construction-selection">
              <div className="build-diagram-viewer">
                <div className="build-diagram-container">
                  <img 
                    src={blindDadoOption.imagePath} 
                    alt={blindDadoOption.name}
                    className="build-construction-diagram"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const placeholder = e.currentTarget.nextElementSibling as HTMLElement;
                      if (placeholder) placeholder.style.display = 'block';
                    }}
                  />
                  <div className="build-diagram-placeholder" style={{ display: 'none' }}>
                    <p>Diagram coming soon</p>
                    <p>{blindDadoOption.name}</p>
                  </div>
                </div>
              </div>

              <div className="build-construction-info">
                <h3>Blind Dado Configuration</h3>
                
                <div className="dado-parameters">
                  <div className="dado-depth-input">
                    <label>Blind Dado Offset/Rebate (inches)</label>
                    <input 
                      type="number"
                      className="input"
                      step="0.0625"
                      value={blindDadoOffset}
                      onChange={(e) => setBlindDadoOffset(parseFloat(e.target.value) || 0.125)}
                      min="0.0625"
                      max="2.0"
                    />
                    <small style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                      = {toFraction(blindDadoOffset)}"
                    </small>
                  </div>

                  <div className="form-group">
                    <label>
                      <input
                        type="checkbox"
                        checked={blindDadoFrontsOnly}
                        onChange={(e) => setBlindDadoFrontsOnly(e.target.checked)}
                        style={{ marginRight: '8px' }}
                      />
                      Blind dados for fronts only
                    </label>
                  </div>
                </div>
                
                <button 
                  className="btn btn-success"
                  onClick={handleBlindDadoConfig}
                >
                  Complete Blind Dado Configuration
                </button>
              </div>
            </div>
          )}

          {/* Step 5: Toe Kicks */}
          {currentStep === 5 && (
            <div className="build-next-steps">
              <h3>Dado Configuration Complete</h3>
              <p><strong>Back Construction:</strong> {backConstructionOptions.find(opt => opt.id === selectedBackConstruction)?.name}</p>
              {(selectedBackConstruction === 'dado-thick-back' || selectedBackConstruction === 'inset-nailer-dado-back') && (
                <p><strong>Back Dado Depth:</strong> {toFraction(dadoDepth)}"</p>
              )}
              <p><strong>Dado Construction:</strong> {dadoConstructionOptions.find(opt => opt.id === dadoConstructionOptions[currentDadoDiagramIndex].id)?.name}</p>
              {hasDados && (
                <>
                  <p><strong>Dado Depth:</strong> {toFraction(dadoDepthStep2)}"</p>
                  {isStepDado && (
                    <p><strong>Step Dado Rebate:</strong> {toFraction(stepDadoRebate)}"</p>
                  )}
                  {isBlindDado && (
                    <p><strong>Blind Dado Offset:</strong> {toFraction(blindDadoOffset)}"</p>
                  )}
                </>
              )}
              <button className="btn btn-primary" onClick={() => setCurrentStep(4)}>
                Continue to Toe Kicks
              </button>
            </div>
          )}

          {/* Step 5: Toe Kicks */}
          {currentStep === 5 && (
            <div className="build-next-steps">
              <h3>Ready for Toe Kick Configuration</h3>
              <p><strong>Back Construction:</strong> {backConstructionOptions.find(opt => opt.id === selectedBackConstruction)?.name}</p>
              <p><strong>Dado Construction:</strong> {dadoConstructionOptions.find(opt => opt.id === selectedDadoType)?.name || 'No Dados'}</p>
              {hasDados && (
                <>
                  {useBlindDados && (
                    <>
                      <p><strong>Blind Dados:</strong> Yes{blindDadoFrontsOnly ? ' (fronts only)' : ''}</p>
                      <p><strong>Dado Depth:</strong> {toFraction(dadoDepthStep2)}"</p>
                      {selectedDadoType === 'step-dados' && (
                        <p><strong>Step Dado Rebate:</strong> {toFraction(stepDadoRebate)}"</p>
                      )}
                      <p><strong>Blind Dado Offset/Rebate:</strong> {toFraction(blindDadoOffset)}"</p>
                    </>
                  )}
                  {useBlindDados === false && (
                    <>
                      <p><strong>Blind Dados:</strong> No (standard dados)</p>
                      <p><strong>Dado Depth:</strong> {toFraction(dadoDepthStep2)}"</p>
                      {selectedDadoType === 'step-dados' && (
                        <p><strong>Step Dado Rebate:</strong> {toFraction(stepDadoRebate)}"</p>
                      )}
                    </>
                  )}
                </>
              )}
              <p><em>Toe kick configuration will be implemented next...</em></p>
              <button className="btn btn-primary" onClick={onClose}>
                Continue Build Process
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}